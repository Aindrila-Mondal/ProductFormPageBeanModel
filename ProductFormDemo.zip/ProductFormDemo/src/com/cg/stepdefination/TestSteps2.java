package com.cg.stepdefination;


import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.pagebean.ProductPage2;

import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestSteps2 {
	
	private WebDriver driver;
	private ProductPage2 pageBean;
	
	@Before
	public void setupenvironmemt()
	{
		System.setProperty("webdriver.chrome.driver","MyDriver\\chromedriver.exe");
		driver=new ChromeDriver();
		
	}
	
	
	@When("^Internet is working$")
	public void internet_is_working() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@When("^User is logged in$")
	public void user_is_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		
		driver.get("C:\\Users\\AIMONDAL\\Desktop\\Selinium_HTML_pages\\ProductForm.html");
		
		pageBean=PageFactory.initElements(driver,ProductPage2.class );
	}

	@When("^user is trying to submit data without entering product code$")
	public void user_is_trying_to_submit_data_without_entering_product_code() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		pageBean.clickSubmit();
		/*
		 * pageBean .setProName("Mobile"); pageBean.setQuantity("2");
		 * pageBean.setRadio("Electronics");
		 */
	}
	@Then("^'ProductCode should not be empty' alert message should display$")
    public void ProductCode_should_not_be_empty_alert_message_should_display()
    {
		Alert alert =driver.switchTo().alert();
		String expectedAlertMessage="ProductCode should not be empty";
		String actualAlertMessage=alert.getText();
		Assert.assertEquals(expectedAlertMessage,actualAlertMessage);
		alert.accept();
    }
	

	@When("^user is trying to submit data without entering product name$")
	public void user_is_trying_to_submit_data_without_entering_product_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		pageBean.setProCode("1");
		pageBean.clickSubmit();
	}
	
	@Then("^'ProductName should not be empty' alert message should display$")
    public void ProductName_should_not_be_empty_alert_message_should_display()
    {
		Alert alert =driver.switchTo().alert();
		String expectedAlertMessage="ProductName should not be empty";
		String actualAlertMessage=alert.getText();
		Assert.assertEquals(expectedAlertMessage,actualAlertMessage);
		alert.accept();
    }
	

	@When("^user is trying to submit data without entering ProductQuantity$")
	public void user_is_trying_to_submit_data_without_entering_ProductQuantity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		pageBean.setProName("Mobile");
		pageBean.clickSubmit();
		
	 }
	@Then("^'ProductQuantity should not be empty' alert message should display$")
    public void ProductQuantity_should_not_be_empty_alert_message_should_display()
    {
		Alert alert =driver.switchTo().alert();
		String expectedAlertMessage="ProductQuantity should not be empty";
		String actualAlertMessage=alert.getText();
		Assert.assertEquals(expectedAlertMessage,actualAlertMessage);
		alert.accept();
    }
	


	@When("^user is trying to submit data without entering ProductType$")
	public void user_is_trying_to_submit_data_without_entering_ProductType() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		pageBean.setQuantity("2");
		pageBean.clickSubmit();
	}
	@Then("^'ProductType should not be empty' alert message should display$")
    public void ProductType_should_not_be_empty_alert_message_should_display()
    {
		Alert alert =driver.switchTo().alert();
		String expectedAlertMessage="ProductType should not be empty";
		String actualAlertMessage=alert.getText();
		Assert.assertEquals(expectedAlertMessage,actualAlertMessage);
		alert.accept();
    }
	@When("^user is trying to submit data without entering valid ProductQuantity$")
	public void user_is_trying_to_submit_data_without_entering_valid_ProductQuantity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageBean.setRadio("Electronics");
		pageBean.setQuantity("9");
		pageBean.clickSubmit();
	}
	@Then("^Select correct ProductQuantity alert message should display$")
    public void Select_correct_ProductQuantity_alert_message_should_display()
    {
		Alert alert =driver.switchTo().alert();
		String expectedAlertMessage="Select correct ProductQuantity";
		String actualAlertMessage=alert.getText();
		Assert.assertEquals(expectedAlertMessage,actualAlertMessage);
		alert.accept();
    }
	/*
	 * @Then("^\"([^\"]*)\" alert message should display$") public void
	 * alert_message_should_display(String arg1) throws Throwable { // Write code
	 * here that turns the phrase above into concrete actions Thread.sleep(500);
	 * pageBean.clickSubmit(); Thread.sleep(500); Alert alert =
	 * driver.switchTo().alert();
	 * 
	 * System.out.println(alert.getText()); System.out.println(arg1);
	 * Assert.assertEquals( alert.getText(), arg1); alert.accept(); }
	 */

@When("^user provides the data \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
public void user_provides_the_data(String arg1, String arg2, String arg3, String arg4) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	pageBean.setProCode(arg1);
	pageBean.setProName(arg2);
	pageBean.setQuantity(arg3);
	pageBean.setRadio(arg4);
}

	@When("^User click on Submit button$")
	public void user_click_on_Submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageBean.clickSubmit();
		 Thread.sleep(500);
		 Thread.sleep(500);
		  Alert alert = driver.switchTo().alert();
		  
		 Assert.assertEquals(alert.getText(),"All correct");
		 alert.accept();
	}

	@Then("^Go to success page$")
	public void go_to_success_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     Assert.assertEquals(pageBean.currentPageTitle(driver),"success page");
	}

}



