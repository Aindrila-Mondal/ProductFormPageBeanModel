package com.cg.stepdefination;



import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.pagebean.ProductPage2;

import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestSteps2 {
	
	private WebDriver driver;
	private ProductPage2 pageBean;
	
	@Before
	public void setupenvironmemt()
	{
		System.setProperty("webdriver.chrome.driver","MyDriver\\chromedriver.exe");
		driver=new ChromeDriver();
		
	}
	
	
	@When("^Internet is working$")
	public void internet_is_working() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     
	}

	@When("^User is logged in$")
	public void user_is_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		
		driver.get("C:\\Users\\AIMONDAL\\Desktop\\Selinium_HTML_pages\\ProductForm.html");
		
		pageBean=PageFactory.initElements(driver,ProductPage2.class );
	}

	@When("^user is trying to submit data without entering product code$")
	public void user_is_trying_to_submit_data_without_entering_product_code() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		pageBean.clickSubmit();
		/*
		 * pageBean .setProName("Mobile"); pageBean.setQuantity("2");
		 * pageBean.setRadio("Electronics");
		 */
	}
	

	@When("^user is trying to submit data without entering product name$")
	public void user_is_trying_to_submit_data_without_entering_product_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		pageBean.setProCode("1");
		pageBean.clickSubmit();
	}


	@When("^user is trying to submit data without entering ProductQuantity$")
	public void user_is_trying_to_submit_data_without_entering_ProductQuantity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		pageBean.setProName("Mobile");
		pageBean.clickSubmit();
		
	 }



	@When("^user is trying to submit data without entering ProductType$")
	public void user_is_trying_to_submit_data_without_entering_ProductType() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		pageBean.setQuantity("2");
		pageBean.clickSubmit();
	}

	
	 @Then("^\"([^\"]*)\" alert message should display$")
	 public void alert_message_should_display(String arg1) throws Throwable { 
	 Thread.sleep(500);
	 pageBean.clickSubmit(); 
	 Thread.sleep(500); 
	 Alert alert =driver.switchTo().alert();
	 System.out.println(alert.getText()); System.out.println(arg1);
	 Assert.assertEquals( alert.getText(), arg1); 
	 alert.accept(); 
	 }
	

@When("^user provides the data \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
public void user_provides_the_data(String arg1, String arg2, String arg3, String arg4) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	pageBean.setProCode(arg1);
	pageBean.setProName(arg2);
	pageBean.setQuantity(arg3);
	pageBean.setRadio(arg4);
}

	@When("^User click on Submit button$")
	public void user_click_on_Submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageBean.clickSubmit();
		 Thread.sleep(500);
		 Thread.sleep(500);
		  Alert alert = driver.switchTo().alert();
		  
		 Assert.assertEquals(alert.getText(),"All correct");
		 alert.accept();
	}

	@Then("^Go to success page$")
	public void go_to_success_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     Assert.assertEquals(pageBean.currentPageTitle(driver),"success page");
	}

}



