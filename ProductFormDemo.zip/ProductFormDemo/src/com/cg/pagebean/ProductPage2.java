package com.cg.pagebean;


	import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

	public class ProductPage2 {
		
		
		@FindBy(how=How.NAME,name="procode")
		private WebElement productcode;
		
		
		@FindBy(how=How.NAME,name="proname")
		private WebElement productname;
		
		
		@FindBy(how=How.NAME,name="quantity")
		private WebElement productquantity;
		
		@FindBy(how=How.NAME,name="radio")
		private WebElement producttype;
		
		@FindBy(name="submit")
		private WebElement submitbtn;
		
		
		public void setProCode(String code)
		{
			this.productcode.sendKeys(code);
		}
		
		public String getProCode()
		{
			return productcode.getAttribute("value");
		}
		public void setProName(String name)
		{
			//driver.findElement(proname).clear();
			this.productname.sendKeys(name);
		}
		public String getProName()
		{
			return productname.getAttribute("value");
		}
		public void setQuantity(String qty)
		{
			//driver.findElement(quantity).clear();
			if(!qty.equals(""))
			{
			Select selectType=new Select(this.productquantity);
			selectType.selectByVisibleText(qty);
			}
		}
		public String getQuantity()
		{
			//return new Select(this.productquantity).getFirstSelectedOption().getText();
			return productquantity.getAttribute("value");
		}
		
		public void setRadio(String code)
		{
			//driver.findElement(radio).clear();
			List<WebElement> radioBoxEmt=(List<WebElement>) this.producttype;
			for(WebElement var : radioBoxEmt)
			{
				String rValue = var.getAttribute("value");
				 
				 // Select the checkbox it the value of the checkbox is same what you are looking for
				 
				 if (rValue.equalsIgnoreCase(code)){
					 var.click();
					 break;
				 }
			}
		}
		public String getRadio()
		{
			return producttype.getAttribute("value");
		}
		public void clickSubmit(){

			submitbtn.submit();

	    }

		

		public Object currentPageTitle(WebDriver driver) {
			// TODO Auto-generated method stub
			return driver.getTitle();
		}
		
	
		
		
		
		
		
		
		
		
	
	
		
		
		
		
		
	}


